const initState = {
    recipes: []
}

const recipesReducer = (state = initState, action) => {
    switch(action.type){
        default:
            return state;
    }
}

export default recipesReducer;