import React,{Component} from "react";
import MenuModal from "./MenuModal"
//import './MenuDialog.css';

class MenuDialog extends Component{
    
    render(){

        return(
          <MenuModal day="Monday" number ="1"></MenuModal>
        )
    }
    
    

}

export default MenuDialog
