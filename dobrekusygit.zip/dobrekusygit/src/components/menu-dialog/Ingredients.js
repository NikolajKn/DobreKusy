import React,{Component} from "react";
import {Button,Card,Col,InputGroup,FormControl, Form,Dropdown} from 'react-bootstrap'
import { Typeahead } from 'react-bootstrap-typeahead';
import {connect} from "react-redux";
import {compose} from "redux";
import { firestoreConnect } from "react-redux-firebase";
import {addItem} from "../../store/actions/recipeActions"

var expirujuce =[];
var suroviny =[];
var oznaceneExp =[];
var oznaceneNexp =[];
var neexpirujuce =[];
var pomfilter = []

class Ingredients extends Component{
    
    constructor(props){
        super(props);
        suroviny =props.storage 
        console.log(props.storage)
        console.log(suroviny)
      this.state = {
        checked:[],
       };
    }

    componentDidUpdate(prevProps) {
      if(this.props !== prevProps){
         expirujuce =[];
         neexpirujuce =[];
        for(let i=0;i<this.props.storage.length;i++) {
              var itemDate = new Date(this.props.storage[i].expirationDate.seconds*1000)
              var currentDate = new Date(Date.now())
              var dateDiff =  Math.floor(( itemDate - currentDate ) / 86400000);  
              if(dateDiff <= 7){
                  expirujuce.push(this.props.storage[i])
              }
              else{
                  neexpirujuce.push(this.props.storage[i])

              }
          }  
        
        if (this.state.checked.length == 0) {
            oznaceneExp = []
            oznaceneNexp=[];
            for(let i = 0; i < expirujuce.length; i++){
                oznaceneExp.push(false)
            }
            for(let i = 0; i < neexpirujuce.length; i++){
                oznaceneNexp.push(false)
            }
            this.setState({ checked: oznaceneExp })
        }  
        console.log(expirujuce)
        
      }
    }

   

 expiruju = (e) =>{
     var index = e.target.id
     if(index===""){
         index=0;
     }
     
            if(oznaceneExp[index]==false){ 
                oznaceneExp[index] = true
            }
            else{
                oznaceneExp[index] = false
            }
            this.filtruj()
        }

  neexpiruju = (e) =>{    
      var index = e.target.id 
      if(index===""){
          index=0;
      }
            if(oznaceneNexp[index]==false){       
                oznaceneNexp[index] = true
            }
            else{
                oznaceneNexp[index] = false
            }
            this.filtruj()
        }

 filtruj = () => {
            pomfilter = []
            for (let i = 0; i < oznaceneExp.length; i++) {
                if (oznaceneExp[i] == true) {
                    pomfilter.push(expirujuce[i].name)
                }
            }
            for (let i = 0; i < oznaceneNexp.length; i++) {
                if (oznaceneNexp[i] == true) {
                    console.log(neexpirujuce[i].name)
                    pomfilter.push(neexpirujuce[i].name)
                }
            }
            this.props.setNewFilter(pomfilter)
    }  

    render(){
        return(
            <>
          <Card style = {{borderColor:"#64697A",padding:"0",margin:"0",border:"0",borderRadius:"0px"}}>
              <Card.Header style={{ backgroundColor: '#64697A', color:'white',borderRadius:"0px"}}> 
              <h4 className="float-left" style={{width:"100%"}}>Close to expire:</h4>
              
              </Card.Header>
  
              <Card.Body style= {{overflow: "auto", height:"190px"}}>
                
  <div style={{marginTop:"10px"}}>
  
  {expirujuce.map((value, index) => 
                    <Form.Check
                      key={index}
                      type="checkbox"
                      label= {expirujuce[index].name+ " "+ expirujuce[index].amount +" "+ expirujuce[index].measurementUnit  }
                      name="formHorizontalRadios"
                      id={index}
                      onChange = {this.expiruju}
                      style = {{fontSize: "20px", color:"red"}}
                    />
            ) }
  
  </div>
              </Card.Body>
            </Card>

            <Card style = {{borderColor:"#64697A",borderRadius:"0px",border:"0"}}>
             <Card.Header style={{ backgroundColor: '#64697A', color:'white',borderRadius:"0px"}}> 
              <h4 className="float-left" style={{width:"100%"}}>Other ingredients:</h4>
              
              </Card.Header>
  
              <Card.Body style= {{overflow: "auto", height:"180px"}}>
                <div style={{marginTop:"10px"}}>
  
                {neexpirujuce.map((value, index) => 
                    <Form.Check
                      key={index}
                      type="checkbox"
                      label= {neexpirujuce[index].name+ " "+ neexpirujuce[index].amount +" "+ neexpirujuce[index].measurementUnit  }
                      name="formHorizontalRadios"
                      id={index}
                      onChange = {this.neexpiruju}
                      style = {{fontSize: "20px"}}
                    />
            ) }
  
  </div>
             
                  </Card.Body>
            </Card>
  </>
          )


    }
    
    

}


const setNewFilter = (filter) => {
  return {
      type: "SET_FILTER", 
      payload: filter
  }
}

const mapStateToProps = (state, props) => {
  return {
      storage: state.firestore.ordered.storage,
      menuState: state.menu
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setNewFilter: (filter) => dispatch(setNewFilter(filter)),
    addItem: () => dispatch(addItem())
  }
}

export default compose(
  connect(mapStateToProps,mapDispatchToProps),
  firestoreConnect([{collection:"storage"}])
)(Ingredients)
